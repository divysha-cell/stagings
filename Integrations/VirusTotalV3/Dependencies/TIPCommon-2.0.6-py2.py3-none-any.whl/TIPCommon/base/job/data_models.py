from __future__ import annotations

from typing import Any

from ...data_models import JobParamType
from ...types import SingleJson


class JobParameter:
    """A general script parameter object.

    Attributes:
        full_dict (dict[str, Any]): The original dict received from the API.
        id (int | None): The parameter's ID.
        is_mandatory (bool):
            Whether the parameter is mandatory or not.
            (prioritized over 'value' in playbooks).
        name (str | None): The parameter's name.
        type (ActionParamType): The type of the parameter.
        value (Any):
            The default value of the parameter
            (prioritized over 'default_value' in manual actions).
    """

    def __init__(self, input_dict: SingleJson) -> None:
        self.full_dict: SingleJson = input_dict
        self.id_: int | None = input_dict.get('id')
        self.is_mandatory: bool = input_dict.get('isMandatory', False)
        self.name: str = input_dict.get('name', 'No name found!')
        self.type_ = JobParamType(input_dict.get('type', -1))
        self.value: Any = input_dict.get('value')
