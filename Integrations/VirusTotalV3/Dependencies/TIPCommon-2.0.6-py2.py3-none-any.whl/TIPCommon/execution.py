from __future__ import annotations

import functools
import inspect
from typing import Any, Callable


def main(class_: Callable[[], Any]) -> Callable[[], Any]:
    @functools.wraps(class_)
    def do_main() -> Any:
        if not inspect.isclass(class_):
            raise TypeError("The main decorator supports classes only")

        if callable(class_) and hasattr(class_, "run") and callable(class_.run):
            class_().run()

        elif callable(class_) and hasattr(class_, "start") and callable(class_.start):
            class_().start()

        else:
            raise RuntimeError("Could not run script using 'run' or 'start' methods")

    if __name__ == "__main__":
        do_main()

    return class_
